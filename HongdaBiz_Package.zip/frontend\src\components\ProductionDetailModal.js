import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { inventoryProductionAPI } from '../services/api';
import { useModalDraggable } from '../hooks/useModalDraggable';

/**
 * 재고 작업 상세 보기 모달 컴포넌트
 * (생산/소분 등 작업 내역의 원재료 및 산출물 상세 표시)
 */
function ProductionDetailModal({ isOpen, onClose, jobId, highlightId }) {
    const [loading, setLoading] = useState(false);
    const [jobData, setJobData] = useState(null);
    const [error, setError] = useState(null);
    const { handleMouseDown, draggableStyle } = useModalDraggable(isOpen);
    const highlightedRowRef = useRef(null);

    // 작업 상세 정보 로드
    useEffect(() => {
        if (isOpen && jobId) {
            setJobData(null); // Clear previous data
            loadJobDetail();
        }
    }, [isOpen, jobId]);

    const loadJobDetail = async () => {
        try {
            setLoading(true);
            setError(null);
            const response = await inventoryProductionAPI.getDetail(jobId);
            const rawData = response.data.data;

            // 데이터 정규화 (백엔드 필드 명칭과 모달 기대 필드 조율)
            const normalized = {
                ...rawData,
                job_date: rawData.created_at,
                job_type: '생산 작업',
                // 재료비 합계 + 추가 비용
                total_cost: (rawData.ingredients || []).reduce((sum, ing) => sum + (Number(ing.unit_price) * Number(ing.used_quantity)), 0) + Number(rawData.additional_cost || 0),
                notes: rawData.memo,
                outputs: [{
                    id: rawData.output_inventory_id,
                    product_name: rawData.output_product_name,
                    product_weight: rawData.output_product_weight,
                    grade: rawData.output_product_grade,
                    quantity: rawData.output_quantity,
                    unit_cost: rawData.unit_cost,
                    warehouse_name: rawData.output_warehouse_name
                }]
            };

            setJobData(normalized);
        } catch (err) {
            console.error('작업 상세 조회 오류:', err);
            setError('작업 정보를 불러오는데 실패했습니다.');
        } finally {
            setLoading(false);
        }
    };

    // ESC 키로 닫기
    useEffect(() => {
        const handleEsc = (e) => {
            if (e.key === 'Escape' && isOpen) {
                onClose();
            }
        };
        window.addEventListener('keydown', handleEsc);
        return () => window.removeEventListener('keydown', handleEsc);
    }, [isOpen, onClose]);

    // 강조 항목으로 스크롤
    useEffect(() => {
        if (isOpen && jobData && highlightId) {
            const timer = setTimeout(() => {
                if (highlightedRowRef.current) {
                    highlightedRowRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }, 500);
            return () => clearTimeout(timer);
        }
    }, [isOpen, jobData, highlightId]);

    if (!isOpen) return null;

    const formatCurrency = (value) => {
        return new Intl.NumberFormat('ko-KR').format(value || 0);
    };

    const formatDate = (dateString) => {
        if (!dateString) return '-';
        return dateString.split('T')[0];
    };

    return createPortal(
        <div className="modal-overlay" style={{ zIndex: 10100 }}>
            <div
                className="styled-modal"
                onClick={(e) => e.stopPropagation()}
                style={{
                    width: '800px',
                    maxWidth: '95vw',
                    maxHeight: '90vh',
                    display: 'flex',
                    flexDirection: 'column',
                    ...draggableStyle
                }}
            >
                {/* 헤더 */}
                <div
                    className="modal-header draggable-header"
                    onMouseDown={handleMouseDown}
                >
                    <h2 className="drag-pointer-none" style={{ margin: 0, fontSize: '1.25rem', color: '#1e293b' }}>
                        🛠️ 작업 상세 내역
                    </h2>
                    <button className="close-btn drag-pointer-auto" onClick={onClose}>&times;</button>
                </div>

                {/* 바디 */}
                <div className="modal-body" style={{ overflowY: 'auto', padding: '1.5rem' }}>
                    {loading ? (
                        <div style={{ textAlign: 'center', padding: '3rem', color: '#64748b' }}>불러오는 중...</div>
                    ) : error ? (
                        <div style={{ textAlign: 'center', padding: '3rem', color: '#dc2626' }}>{error}</div>
                    ) : jobData ? (
                        <>
                            {/* 작업 기본 정보 */}
                            <div style={{
                                display: 'grid',
                                gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                                gap: '1rem',
                                marginBottom: '2rem',
                                padding: '1rem',
                                backgroundColor: '#f8fafc',
                                borderRadius: '8px',
                                border: '1px solid #e2e8f0'
                            }}>
                                <div>
                                    <div style={{ fontSize: '0.85rem', color: '#64748b', marginBottom: '0.25rem' }}>작업일자</div>
                                    <div style={{ fontWeight: '600' }}>{formatDate(jobData.job_date)}</div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '0.85rem', color: '#64748b', marginBottom: '0.25rem' }}>작업유형</div>
                                    <div style={{ fontWeight: '600' }}>
                                        {jobData.job_type === 'REPACK' ? '소분/재포장' : jobData.job_type}
                                    </div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '0.85rem', color: '#64748b', marginBottom: '0.25rem' }}>총 비용</div>
                                    <div style={{ fontWeight: '600', color: '#1e293b' }}>
                                        {formatCurrency(jobData.total_cost)}원
                                    </div>
                                </div>
                                <div style={{ gridColumn: '1 / -1' }}>
                                    <div style={{ fontSize: '0.85rem', color: '#64748b', marginBottom: '0.25rem' }}>비고</div>
                                    <div style={{ color: '#475569' }}>{jobData.notes || '-'}</div>
                                </div>
                            </div>

                            {/* 소모 원재료 */}
                            <div style={{ marginBottom: '2rem' }}>
                                <h3 style={{ fontSize: '1.1rem', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                    📉 소모 원재료
                                </h3>
                                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
                                    <thead>
                                        <tr style={{ backgroundColor: '#34495e', color: '#ffffff' }}>
                                            <th style={{ padding: '0.75rem', textAlign: 'left', fontWeight: '600' }}>품목</th>
                                            <th style={{ padding: '0.75rem', textAlign: 'center', fontWeight: '600' }}>출하주</th>
                                            <th style={{ padding: '0.75rem', textAlign: 'right', fontWeight: '600' }}>수량</th>
                                            <th style={{ padding: '0.75rem', textAlign: 'right', fontWeight: '600' }}>평균단가</th>
                                            <th style={{ padding: '0.75rem', textAlign: 'right', fontWeight: '600' }}>금액</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {jobData.ingredients?.map((item, idx) => {
                                            const isHighlighted = highlightId && String(item.id) === String(highlightId);
                                            return (
                                                <tr
                                                    key={idx}
                                                    ref={isHighlighted ? highlightedRowRef : null}
                                                    className={isHighlighted ? 'highlighted-row' : ''}
                                                    style={{ borderBottom: '1px solid #e2e8f0' }}
                                                >
                                                    <td style={{ padding: '0.75rem', fontWeight: isHighlighted ? '700' : 'normal' }}>
                                                        {item.product_name} {item.product_weight}kg {item.grade}
                                                        {isHighlighted && <span style={{ marginLeft: '8px', color: '#f08c00', fontSize: '0.8rem' }}>👈 선택됨</span>}
                                                    </td>
                                                    <td style={{ padding: '0.75rem', textAlign: 'center' }}>{item.sender || '-'}</td>
                                                    <td style={{ padding: '0.75rem', textAlign: 'right' }}>{item.used_quantity}</td>
                                                    <td style={{ padding: '0.75rem', textAlign: 'right' }}>{formatCurrency(item.unit_price)}</td>
                                                    <td style={{ padding: '0.75rem', textAlign: 'right', fontWeight: '500' }}>
                                                        {formatCurrency(item.used_quantity * item.unit_price)}
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>

                            {/* 생산 산출물 */}
                            <div>
                                <h3 style={{ fontSize: '1.1rem', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                    📈 생산 산출물
                                </h3>
                                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
                                    <thead>
                                        <tr style={{ backgroundColor: '#34495e', color: '#ffffff' }}>
                                            <th style={{ padding: '0.75rem', textAlign: 'left', fontWeight: '600' }}>품목</th>
                                            <th style={{ padding: '0.75rem', textAlign: 'right', fontWeight: '600' }}>생산수량</th>
                                            <th style={{ padding: '0.75rem', textAlign: 'right', fontWeight: '600' }}>산출단가</th>
                                            <th style={{ padding: '0.75rem', textAlign: 'right', fontWeight: '600' }}>총액</th>
                                            <th style={{ padding: '0.75rem', textAlign: 'center', fontWeight: '600' }}>보관창고</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {jobData.outputs?.map((item, idx) => {
                                            const isHighlighted = highlightId && String(item.id) === String(highlightId);
                                            return (
                                                <tr
                                                    key={idx}
                                                    ref={isHighlighted ? highlightedRowRef : null}
                                                    className={isHighlighted ? 'highlighted-row' : ''}
                                                    style={{ borderBottom: '1px solid #e2e8f0' }}
                                                >
                                                    <td style={{ padding: '0.75rem', fontWeight: isHighlighted ? '700' : 'normal' }}>
                                                        {item.product_name} {item.product_weight}kg {item.grade}
                                                        {isHighlighted && <span style={{ marginLeft: '8px', color: '#f08c00', fontSize: '0.8rem' }}>👈 선택됨</span>}
                                                    </td>
                                                    <td style={{ padding: '0.75rem', textAlign: 'right', fontWeight: 'bold', color: '#2563eb' }}>
                                                        {item.quantity}
                                                    </td>
                                                    <td style={{ padding: '0.75rem', textAlign: 'right' }}>{formatCurrency(item.unit_cost)}</td>
                                                    <td style={{ padding: '0.75rem', textAlign: 'right', fontWeight: '500' }}>
                                                        {formatCurrency(item.quantity * item.unit_cost)}
                                                    </td>
                                                    <td style={{ padding: '0.75rem', textAlign: 'center' }}>{item.warehouse_name}</td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </>
                    ) : (
                        <div style={{ textAlign: 'center', padding: '3rem', color: '#64748b' }}>정보가 없습니다.</div>
                    )}
                </div>

                {/* 푸터 */}
                <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '1rem 1.5rem', backgroundColor: '#f8fafc' }}>
                    <button className="modal-btn modal-btn-primary" onClick={onClose}>닫기</button>
                    {/* 필요 시 작업 취소 버튼 등을 여기에 추가 가능 */}
                </div>
            </div>
        </div>,
        document.body
    );
}

export default ProductionDetailModal;
