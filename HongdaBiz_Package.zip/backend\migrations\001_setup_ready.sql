-- 샘플 마이그레이션: _migrations 테이블은 MigrationRunner가 자동으로 만듭니다.
-- 향후 DB 변경 시 여기에 .sql 또는 .js 파일을 추가하세요.
-- 파일명은 001_설명.sql 과 같이 숫자로 시작하면 순서대로 실행됩니다.
-- 예: 002_add_index_to_trades.sql

SELECT 'Migration system ready' as status;
