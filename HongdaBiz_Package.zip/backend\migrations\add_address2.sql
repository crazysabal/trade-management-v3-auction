-- company_info 테이블에 address2 컬럼 추가
ALTER TABLE company_info ADD COLUMN address2 VARCHAR(200) NULL AFTER address;











